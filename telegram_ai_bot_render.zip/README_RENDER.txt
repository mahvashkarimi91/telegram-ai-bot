RENDER SETUP

1. Upload this project to a GitHub repository.
2. In Render, create a new Background Worker from that repository.
3. Render can use render.yaml automatically, or set:
   Build Command: pip install -r requirements.txt
   Start Command: python telegram_ai_bot.py

4. Add these environment variables in Render:
   TELEGRAM_BOT_TOKEN = your BotFather token
   OPENROUTER_API_KEY = your OpenRouter key
   OPENROUTER_MODEL = openrouter/free

Do NOT put the API keys directly in the code or GitHub.

IMPORTANT:
This bot replies to text messages that Telegram delivers to it.
For a channel workflow, Telegram channel posts and discussion-group messages
have different delivery behavior. Test the bot in a private group/discussion
first, then configure the channel's linked discussion and permissions.
